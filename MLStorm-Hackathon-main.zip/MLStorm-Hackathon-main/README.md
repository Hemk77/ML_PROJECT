# MLStorm-Hackathon
This project is made for ML Storm Hacakathon as part of Vintra 24'
